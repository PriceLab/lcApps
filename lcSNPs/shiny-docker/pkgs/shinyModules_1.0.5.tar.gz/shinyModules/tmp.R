library(dplyr)
library(shiny)
library(shinyjs)
u <- fluidPage(
  titlePanel("Simple Selectable Reactive Function"),
  sidebarLayout(
    sidebarPanel(),
    mainPanel(
      h2("Results"),
      fluidRow(
        column(2, textInput("input_ID", label = "Cusip 1",value = "123")),
        column(2, textInput("output_name", label = "Firstname") %>% disabled()),
        column(2, textInput("output_lastname", label = "Lastname") %>% disabled()),
        column(2, textInput("output_age", label = "Age") %>% disabled())))))

s <- function(input,output, session){

  observe({
    id <- input$input_ID
    set.seed(id)
    df <- list(firstname = sample(LETTERS, 1), lastname = sample(LETTERS, 1), age = sample(1:100, 1))
    updateTextInput(session, inputId = "output_name", label = df[["firstname"]])
    updateTextInput(session, inputId = "output_lastname", label = df[["lastname"]])
    updateTextInput(session, inputId = "output_age", label = df[["age"]])
  })
}
runApp(shinyApp(ui=u,server=s), port=9999)

