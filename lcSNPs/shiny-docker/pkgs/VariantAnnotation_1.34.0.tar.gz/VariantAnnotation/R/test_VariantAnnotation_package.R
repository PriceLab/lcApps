.test <- function() BiocGenerics:::testPackage("VariantAnnotation")
